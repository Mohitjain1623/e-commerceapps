package com.ujjaval.ecommerce.searchsuggestionservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SearchSuggestionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
