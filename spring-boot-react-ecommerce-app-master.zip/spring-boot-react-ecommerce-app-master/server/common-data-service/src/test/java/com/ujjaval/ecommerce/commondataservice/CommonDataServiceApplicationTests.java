package com.ujjaval.ecommerce.commondataservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommonDataServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
