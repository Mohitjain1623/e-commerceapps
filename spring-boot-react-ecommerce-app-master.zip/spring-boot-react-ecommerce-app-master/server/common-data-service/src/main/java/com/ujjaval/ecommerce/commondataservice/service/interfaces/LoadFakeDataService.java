package com.ujjaval.ecommerce.commondataservice.service.interfaces;

public interface LoadFakeDataService {

    boolean loadTestData();
}

